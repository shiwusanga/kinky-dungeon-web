// ============================================================
// KinkyDungeon Mod: 科幻拘束 (SciFi Restraints)
// 版本: 1.3
// 描述: 添加 5 个软科幻风格的全身固定类拘束道具
//       开始游戏时把它们以"松散道具"形式放进背包（不自动装备）
// 用法: 将此文件夹压缩为 ZIP，放入游戏 Mods/ 目录
//       在游戏设置中开启"离线包自动加载 mod"，重启游戏
// ------------------------------------------------------------
// v1.1 修复: 之前直接 KinkyDungeonRestraints.push({...}) 绕过了
//            游戏的 defaultRestraint 默认字段合并，导致 restraint
//            缺少 shrine / events / enemyTags / playerTags 等字段。
//            游戏 KDCanAddRestraint 中 restraint.shrine.includes("Raw")
//            无空值保护，读到 undefined.shrine 直接崩溃。
//            现改用官方 API KinkyDungeonCreateRestraint()（自动补全
//            默认字段），并加兜底 helper 保证字段完整。
// ------------------------------------------------------------
// v1.2 复审修复（对照 main.js 源码逐项排查）:
//   [Bug1] StasisSuit 的 Asset "SeamlessLatexCatsuit" 在游戏中不存在
//          → 装备后不显示模型。改为原版猫服 Asset "SeamlessCatsuit"
//            + AssetGroup "Suit" + Model "CatsuitRestraint"。
//   [Bug2] QuantumCocoon 的 Asset "LatexBag" 同样不存在 → 不显示。
//          改为原版容器 Asset "VacCube" + Model "LatexCube"。
//   [Bug3] 5 件道具所有 escapeChance 全为负 + 全套 Deep 强制装备，
//          且无 helpChance/移除机制 → 玩家永久软锁（数学上无法脱出）。
//          原版即便极难也会留一条正的逃生路（如猫服 Cut 0.1）。现将
//          每件的 Cut(或 Remove) 调为小正值，保留"极难但非不可能"。
//   [健壮性] 注册前查重，避免重复加载 mod 时 push 出重复道具；
//            放入背包前校验 GetRestraintByName 结果非空，防御性编程。
// ------------------------------------------------------------
// v1.3 行为变更: 之前是"开新档自动装备全套"（会导致开局即被 5 件锁死）。
//          现改为"开新档把 5 件以松散道具(LooseRestraint)放进背包"，
//          玩家可自由从背包中使用/穿戴并测试逃脱手感，不会开局即被绑。
// ============================================================

// ---- 工具函数：安全的钩子注入 ----
// 保存原始 KDInitPerks，在其末尾追加装备逻辑
const _originalKDInitPerks = typeof KDInitPerks === "function" ? KDInitPerks : null;

// ---- 安全注册 restraint 的 helper ----
// 优先用游戏官方 API（会用 defaultRestraint 补全所有必需字段）；
// 若 API 不存在则手动补齐关键默认字段后再 push，双保险防止崩溃。
function _addSciFiRestraint(props) {
    // 查重：避免重复加载 mod 时 push 出同名重复道具
    if (Array.isArray(KinkyDungeonRestraints)
        && KinkyDungeonRestraints.some((r) => r && r.name === props.name)) {
        return KinkyDungeonRestraints.find((r) => r && r.name === props.name);
    }
    if (typeof KinkyDungeonCreateRestraint === "function") {
        return KinkyDungeonCreateRestraint(props);
    }
    // 兜底：手动补全 KDCanAddRestraint / KinkyDungeonAddRestraintIfWeaker
    // 会无保护读取的字段，避免 .includes of undefined 崩溃。
    const restraint = Object.assign({
        inventory: true,
        power: 0,
        weight: 0,
        minLevel: 0,
        allFloors: true,
        escapeChance: { "Struggle": 10, "Cut": 10, "Remove": 10 },
        events: [],
        enemyTags: {},
        playerTags: {},
        shrine: [],
    }, props);
    KinkyDungeonRestraints.push(restraint);
    return restraint;
}

// ---- 第1个道具：纳米手臂束缚器 ----
_addSciFiRestraint({
    name: "NanoArmBinder",
    // 纳米臂缚器：蓝色主题
    Asset: "SeamlessLatexArmbinder",
    Color: ["#00CCFF", "#003366"],
    Group: "ItemArms",
    bindarms: true,
    inaccessible: true,
    power: 35,
    weight: 0,
    DefaultLock: "Cyber",
    shrine: ["Metal"],
    escapeChance: {
        "Struggle": -0.8,
        "Cut": 0.05,        // [Bug3修复] 保留一条逃生路，防止永久软锁
        "Remove": -0.1,
        "Pick": -0.3,
        "Unlock": 0.2
    }
});

// ---- 第2个道具：等离子项圈 ----
_addSciFiRestraint({
    name: "PlasmaCollar",
    // 等离子项圈：橙红色主题
    Asset: "LatexCollar2",
    Color: ["#FF4400", "#661100"],
    Group: "ItemNeck",
    power: 25,
    weight: 0,
    DefaultLock: "Cyber",
    shrine: ["Metal"],
    escapeChance: {
        "Struggle": -0.6,
        "Cut": -0.7,
        "Remove": 0.05,     // [Bug3修复] 原为 0.0，给一条可行逃生路
        "Pick": -0.1,
        "Unlock": 0.3
    }
});

// ---- 第3个道具：静滞服 ----
_addSciFiRestraint({
    name: "StasisSuit",
    // 静滞服：紫色主题
    // [Bug1修复] 原 "SeamlessLatexCatsuit" 不存在，改用原版猫服资产
    Asset: "SeamlessCatsuit",
    AssetGroup: "Suit",
    Model: "CatsuitRestraint",
    Color: ["#6600CC", "#1A0033"],
    Group: "ItemTorso",
    inaccessible: true,
    power: 40,
    weight: 0,
    DefaultLock: "Cyber",
    shrine: ["Latex"],
    escapeChance: {
        "Struggle": -0.9,
        "Cut": 0.05,        // [Bug3修复] 保留一条逃生路，防止永久软锁
        "Remove": -0.2,
        "Pick": -0.4,
        "Unlock": 0.15
    }
});

// ---- 第4个道具：赛博缚猪 ----
_addSciFiRestraint({
    name: "CyberHogtie",
    // 赛博缚猪：琥珀色主题
    Asset: "NylonRope",
    Color: ["#CC6600", "#331A00"],
    Group: "ItemLegs",
    bindlegs: true,
    inaccessible: true,
    power: 38,
    weight: 0,
    DefaultLock: "Cyber",
    shrine: ["Rope"],
    escapeChance: {
        "Struggle": -0.85,
        "Cut": 0.05,        // [Bug3修复] 保留一条逃生路，防止永久软锁
        "Remove": -0.15,
        "Pick": -0.35,
        "Unlock": 0.18
    }
});

// ---- 第5个道具：量子封箱 ----
_addSciFiRestraint({
    name: "QuantumCocoon",
    // 量子封箱：青色主题，全方位束缚
    // [Bug2修复] 原 "LatexBag" 不存在，改用原版容器资产 VacCube
    Asset: "VacCube",
    Model: "LatexCube",
    Color: ["#00CCCC", "#003333"],
    Group: "ItemDevices",
    inaccessible: true,
    bindarms: true,
    blockhands: true,
    gag: 1.0,
    blindfold: 1.0,
    power: 45,
    weight: 0,
    DefaultLock: "Cyber",
    shrine: ["Latex"],
    escapeChance: {
        "Struggle": -1.0,
        "Cut": 0.03,        // [Bug3修复] 保留一条逃生路，防止永久软锁
        "Remove": -0.3,
        "Pick": -0.5,
        "Unlock": 0.1
    }
});

// ---- 刷新拘束道具缓存 ----
KinkyDungeonRefreshRestraintsCache();

// ---- 进背包钩子：游戏开始时把 5 件以松散道具形式放入背包（不自动装备）----
// 通过包装 KDInitPerks（天赋初始化函数）在游戏初始化时注入。
// 用 KinkyDungeonInventoryAddLoose 把每件作为未穿戴的 LooseRestraint 放进背包，
// 玩家可自由从背包中使用/穿戴并测试逃脱手感，开局不会被直接绑上。
(function hookInitPerks() {
    if (_originalKDInitPerks) {
        // 防御性放入：先校验 restraint 存在，避免名字对不上时把 undefined
        // 传进 KinkyDungeonInventoryAddLoose 触发崩溃。
        const _addToBag = function (name) {
            const r = KinkyDungeonGetRestraintByName(name);
            if (!r) {
                console.warn("[科幻拘束 Mod] 未找到道具，跳过放入背包: " + name);
                return;
            }
            try {
                // LooseRestraint：未穿戴的松散道具，出现在背包里
                KinkyDungeonInventoryAddLoose(name, undefined, undefined, 1);
            } catch (e) {
                console.error("[科幻拘束 Mod] 放入背包失败: " + name, e);
            }
        };
        KDInitPerks = function () {
            // 先执行原始天赋初始化
            _originalKDInitPerks();
            // 然后把科幻拘束全套放进背包（不自动装备）
            _addToBag("PlasmaCollar");   // 项圈
            _addToBag("NanoArmBinder");  // 臂缚器
            _addToBag("StasisSuit");     // 静滞服
            _addToBag("CyberHogtie");    // 缚猪
            _addToBag("QuantumCocoon");  // 量子封箱
        };
    }
})();

// Mod 加载提示（可在控制台看到）
console.log("[科幻拘束 Mod v1.3] 已加载 5 个道具 + 进背包钩子");
